package MyApp.com;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        Button AllCarsBtn = (Button)findViewById(R.id.AllCarsBtn);
        Button RegCarsBtn = (Button)findViewById(R.id.RegCarsBtn);
        Button ReqBtn = (Button)findViewById(R.id.ReqBtn);
        Button ShowUsersBtn = (Button)findViewById(R.id.ShowUsersBtn);


        AllCarsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(admin.this, AllCarsBtn.class);
                startActivity(intent);
            }
        });

        RegCarsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(admin.this, AllRegisteredCarsBtn.class);
                startActivity(intent);
            }
        });

        ReqBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(admin.this, AdminRequestsBtn.class);
                startActivity(intent);
            }
        });

        ShowUsersBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(admin.this, AdminAllUsersBtn.class);
                startActivity(intent);
            }
        });

    }
}
