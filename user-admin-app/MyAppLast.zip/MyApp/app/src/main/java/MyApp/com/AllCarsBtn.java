package MyApp.com;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class AllCarsBtn extends AppCompatActivity {
    static ArrayList<String> CarsInTheGarageNow = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_cars_btn);

        ListView ListView3 = (ListView) findViewById(R.id.ListView3);
        final ArrayAdapter MyAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, CarsInTheGarageNow);
        ListView3.setAdapter(MyAdapter1);

    }
}
