package MyApp.com;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import background.BackgroundService;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AdminAllUsersBtn extends AppCompatActivity {

    public static ArrayList<String> Users = new ArrayList<String>(); //adding static makes problem! -- solved

    public void updateUserView( final ListView ListView1, final ArrayAdapter MyAdapter1) throws IOException {
        OkHttpClient client = new OkHttpClient();
        String url = "https://counterfunctions20200429005139.azurewebsites.net/api/get-All-Users/";
        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {



        if (response.isSuccessful()) {
            AdminAllUsersBtn.Users.clear();
            MainActivity.users_cars.clear();
            MainActivity.users_passwords.clear();
            final String MyResponse = response.body().string();
            AdminAllUsersBtn.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String[] parts = MyResponse.split(",");
                    String str = "";
                    for (int i = 0; i < parts.length; i++) {
                        String s = parts[i];
                        String part = "";
                        for (int j = 0; j < s.length(); j++) {
                            char c = s.charAt(j);
                            if (Character.isLetterOrDigit(c)) {
                                part = part + c;
                            }
                        }
                        Users.add(part);
                        str = str + part + " ";
                    }
                    ListView1.setAdapter(MyAdapter1);
                }
            });

        }
    }
});
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_all_users_btn);
        final ListView ListView1 = (ListView) findViewById(R.id.LstView1);
        Button AddBtn = (Button) findViewById(R.id.AddRequestBtn);
        Button RemoveBtn = (Button) findViewById(R.id.RemoveRequestBtn);
        final EditText InputText = (EditText) findViewById(R.id.editText2);

        //setup list view: Reminder of the static problem !!
        final ArrayAdapter MyAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Users);

        ListView1.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = (String) parent.getItemAtPosition(position);
                InputText.setText(item);
            }

        });


            // adding items from azure:
            //NoRepetation+=1;
        try {
            updateUserView( ListView1,MyAdapter1);
        } catch (IOException e) {
            e.printStackTrace();
        }



            //ADD Button
            AddBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int c = 0;
                    final String stringval = InputText.getText().toString();
                    for (int i = 0; i < Users.size(); i++) {
                        if (Users.get(i).equals(stringval)) {
                            c++;
                        }
                    }
                    if (!stringval.equals("") && (c == 0)) {
                    /*Users.add(stringval);  //This is the original code before HTTP Request
                    MainActivity.users_cars.add(stringval);
                    MainActivity.users_passwords.add("user"); //default password  */
                        // Update azure table:
                        String add_url = "https://counterfunctions20200429005139.azurewebsites.net/api/update-User/add/" + stringval;
                        OkHttpClient client2 = new OkHttpClient();
                        Request request2 = new Request.Builder()
                                .url(add_url)
                                .build();
                        client2.newCall(request2).enqueue(new Callback() {
                            @Override
                            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                e.printStackTrace();
                            }

                            @Override
                            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                if (response.isSuccessful()) {
                                    AdminAllUsersBtn.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            try {
                                                updateUserView( ListView1,MyAdapter1);
                                            } catch (IOException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });

                                }
                            }
                        });

                        MyAdapter1.notifyDataSetChanged();
                        InputText.setText("");
                    } else if (c > 0) {
                        Toast.makeText(getApplicationContext(), "User already exists!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "User can't be empty!", Toast.LENGTH_LONG).show();
                    }


                }
            });

            //REMOVE Button
            RemoveBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int c = 0;
                    for (int i = 0; i < Users.size(); i++) {
                        String getname = InputText.getText().toString();
                        if (Users.get(i).equals(getname)) {
                        /*Users.remove(getname);  //This is the original code before HTTP Request
                        MainActivity.users_passwords.remove(MainActivity.users_cars.indexOf(getname));
                        MainActivity.users_cars.remove(MainActivity.users_cars.indexOf(getname));*/
                            // Update azure table:
                            String remove_url = "https://counterfunctions20200429005139.azurewebsites.net/api/update-User/remove/" + getname;
                            //System.out.println(remove_url);
                            OkHttpClient client3 = new OkHttpClient();
                            Request request3 = new Request.Builder()
                                    .url(remove_url)
                                    .build();
                            client3.newCall(request3).enqueue(new Callback() {
                                @Override
                                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                    e.printStackTrace();
                                }

                                @Override
                                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                    if (response.isSuccessful()) {
                                        AdminAllUsersBtn.this.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                try {
                                                    updateUserView( ListView1,MyAdapter1);
                                                } catch (IOException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
                                    }
                                }
                            });

                            MyAdapter1.notifyDataSetChanged();
                            InputText.setText("");
                            c++;
                            Toast.makeText(getApplicationContext(), "User has been removed!", Toast.LENGTH_LONG).show();
                            break;
                        }
                    }
                    if (c == 0) {
                        Toast.makeText(getApplicationContext(), "There's no such user!", Toast.LENGTH_LONG).show();
                    }
                }
            });




    }
}

