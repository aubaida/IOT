package MyApp.com;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class UserRequestsBtn extends AppCompatActivity {
    static ArrayList<String> RequestsList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_requests_btn);
        ListView ListView1 = (ListView) findViewById(R.id.LstView1);
        Button AddRequestBtn = (Button) findViewById(R.id.AddRequestBtn);
        Button RemoveRequestBtn = (Button) findViewById(R.id.RemoveRequestBtn);
        final EditText InputText = (EditText) findViewById(R.id.editText2);

        final ArrayAdapter MyAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, RequestsList);
        ListView1.setAdapter(MyAdapter1);

        //ADD REQUEST Button
        AddRequestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int c = 0;
                String stringval = InputText.getText().toString();
                for(int i=0;i<RequestsList.size();i++) {
                    if (RequestsList.get(i).equals(getIntent().getStringExtra("NAME")+" Request to regist: "+stringval)) {
                        c++;
                    }
                }
                if (!stringval.equals("") && (c==0)) {
                    RequestsList.add(getIntent().getStringExtra("NAME")+" Request to regist: "+stringval); // should add the user name that requests
                    MyAdapter1.notifyDataSetChanged();
                    InputText.setText("");
                }else if(c>0){
                    Toast.makeText(getApplicationContext(), "User already exists!", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(getApplicationContext(), "User can't be empty!", Toast.LENGTH_LONG).show();
                }
            }
        });
        //REMOVE REQUEST Button
        RemoveRequestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int c = 0;
                for(int i=0;i<RequestsList.size();i++) {
                    String getname = InputText.getText().toString();
                    if (RequestsList.get(i).equals(getIntent().getStringExtra("NAME")+" Request to regist: "+getname)) {
                        RequestsList.remove(RequestsList.get(i));
                        MyAdapter1.notifyDataSetChanged();
                        InputText.setText("");
                        c++;
                        Toast.makeText(getApplicationContext(), "User has been removed!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }
                if(c==0){
                    Toast.makeText(getApplicationContext(), "There's no such user!", Toast.LENGTH_LONG).show();
                }}
        });
    }
}
