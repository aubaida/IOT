package MyApp.com;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class AdminRequestsBtn extends AppCompatActivity {

    static ArrayList<String> Users_Requesting = new ArrayList<String>();
    static ArrayList<String> CarPlates_Requesting = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_requests_btn);
        //adding request as a test:
        if(!(Users_Requesting.contains("23-456-78"))){ Users_Requesting.add("23-456-78");} //must be one of the Users!
        if(!(CarPlates_Requesting.contains("1234"))){ Users_Requesting.add("1234");}// Users.find("23-456-78") registered CarPlates_Requesting[index=0]

        ListView ListView1 = (ListView) findViewById(R.id.LstView1);
        Button ApproveBtn = (Button) findViewById(R.id.ApproveBtn);
        Button RejectBtn = (Button) findViewById(R.id.RejectBtn);
        EditText InputText = (EditText) findViewById(R.id.editText2);


        // we must add the requests that users has sent.

    }
}
